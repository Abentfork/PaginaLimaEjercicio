//################################################################################
//Introducir una cadena de caracteres e indicar si es un palíndromo. Una palabra 
//palíndroma es aquella que se lee igual adelante que atrás.
//################################################################################



