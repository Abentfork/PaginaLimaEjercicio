//################################################################################
//Realizar un programa que comprueba si una cadena leída por teclado comienza por 
//una subcadena introducida por teclado.
//################################################################################


