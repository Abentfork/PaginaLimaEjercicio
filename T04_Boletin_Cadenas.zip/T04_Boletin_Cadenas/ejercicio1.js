//################################################################################
//Escribir por pantalla cada carácter (en una línea independiente) de una cadena 
//introducida por teclado.
//################################################################################


