//################################################################################
//Pide una cadena y dos caracteres por teclado (valida que sea solo un carácter 
// alfabético), sustituye la aparicián del primer carácter en la cadena por el 
// segundo carácter.
//################################################################################

