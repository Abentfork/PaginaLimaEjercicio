//################################################################################
//Pide una cadena y un carácter por teclado (valida que sea un carácter alfabético) 
//y muestra cuantas veces aparece el carácter en la cadena.
//################################################################################



