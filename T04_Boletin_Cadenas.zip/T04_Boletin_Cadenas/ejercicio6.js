//################################################################################
//Realizar un programa que dada una cadena de caracteres, genere 
//otra cadena resultado de invertir la primera.
//################################################################################

