//################################################################################
//Si tenemos una cadena con un nombre y apellidos, realizar un programa que 
//muestre las iniciales en mayúsculas.
//################################################################################
