//################################################################################
//Realizar un programa que lea una cadena por teclado y convierta las mayúsculas a 
//minúsculas y viceversa.
//################################################################################
