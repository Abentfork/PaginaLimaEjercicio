//################################################################################
//Realizar un programa que dado un nombre de fichero con extensión, muestre el 
// nombre del fichero seguido de una descripción de su tipo. Las extensiones de 
// fichero que deben reconocerse son: 
// txt -> "Archivo de texto" 
// exe -> "Archivo ejecutable"
// pdf -> "Archivo PDF"
// Estas extensiones deberán ser reconocidas tanto en mayúsculas como en minúsculas.
// Si se introduce otra extensión en el nombre de fichero, o no hay extensión, el 
// programa mostrará el mensaje "Archivo de tipo desconocido" .
//################################################################################

